<?php $__env->startSection('cms_content'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Add new content -</h1>
</div>
<br><br>
  <div class="row">
    <div class="col-lg-8">
      <form action="<?php echo e(url('cms/content')); ?>" method="POST">
        <?php echo e(csrf_field()); ?>

          <div class="mb-3">
            <label for="menu-link" class="form-label">Menu Link:</label>
            <select name="menu_id" class="form-control" id="menu-link">
              <option value="">Choose menu link</option>
                <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option <?php if( old('menu_id') == $item['id']): ?> <?php endif; ?> selected="selected" value="<?php echo e($item['id']); ?>"><?php echo e($item['link']); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
          <div class="mb-3">
            <label for="title" class="form-label">Title:</label>
            <input name="title" type="text"  value="<?php echo e(old('title')); ?>" class="form-control" placeholder="title" id="title" aria-describedby="title">
          </div>
          <div class="mb-3">
              <label for="article" class="form-label">Article:</label>
              <textarea id="article" name="article" class="form-control" id="article" rows="3"><?php echo e(old('article')); ?></textarea>
          </div>
        <a href="<?php echo e(url('cms/content')); ?>" class="btn btn-secondary">Cancel</a>
          <input class="btn btn-primary " type="submit" name="submit" value="Save">
    </form>
    </div>
  </div>

  <?php $__env->stopSection(); ?>

<?php echo $__env->make('cms/cms_main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/laravel-shop/resources/views/cms/add_content.blade.php ENDPATH**/ ?>