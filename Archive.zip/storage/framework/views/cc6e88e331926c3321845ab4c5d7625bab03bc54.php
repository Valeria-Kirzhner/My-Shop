<?php $__env->startSection('cms_content'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Edit this category -</h1>
</div>
<br><br>
  <div class="row">
    <div class="col-lg-8">
      <form action="<?php echo e(url('cms/categories/' . $category['id'])); ?>" method="POST" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

        <?php echo e(method_field('PUT')); ?>

        <input type="hidden" name="item_id" value="<?php echo e($category['id']); ?>">
          <div class="mb-3">
            <label for="title" class="form-label">Title:</label>
            <input name="title" type="text"  value="<?php echo e($category['title']); ?>" class="form-control origin-text" placeholder="title" id="title" aria-describedby="title">
          </div>
          <div class="mb-3">
            <label for="url" class="form-label">Url:</label>
            <input name="url" type="text"  value="<?php echo e($category['url']); ?>" class="form-control target-text" placeholder="url" id="url" aria-describedby="url">
          </div>
          <div class="mb-3">
              <label for="article" class="form-label">Article:</label>
              <textarea id="article" name="article" class="form-control" rows="3"><?php echo e($category['article']); ?></textarea>
          </div>
          <div class="mb-3">
            <img width="50" src="<?php echo e(asset('images/' . $category['image'])); ?>" alt=""><br><br>
            <label for="image" class="form-label">Change category image:</label>
            <input type="file" id="image" name="image" class="form-control" rows="3">
          </div>
          <a href="<?php echo e(url('cms/categories')); ?>" class="btn btn-secondary">Cancel</a>
          <input class="btn btn-primary " type="submit" name="Update" value="Save">
      </form>
    </div>
  </div>

  <?php $__env->stopSection(); ?>

<?php echo $__env->make('cms/cms_main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/laravel-shop/resources/views/cms/edit_category.blade.php ENDPATH**/ ?>