<?php $__env->startSection('cms_content'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">MY SHOP site orders</h1>
</div>
<br><br>
  <div class="row">
    <div class="col-lg-12">
      <table class="table table-bordered">
        <thead>
        <tr>
          <th>User</th>
          <th>Order details</th>
          <th>Total</th>
          <th>Date</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($order->name); ?></td>
              <td>
                <ul>
                  <?php $__currentLoopData = unserialize($order->data); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li><?php echo e($item['name']); ?>, Price: <?php echo e($item['price']); ?>,Quantity: <?php echo e($item['quantity']); ?></li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
              </td>
              <td><?php echo e($order->total); ?> $</td>
              <td><?php echo e($order->created_at); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
      </table>
    </div>
  </div>

  <?php $__env->stopSection(); ?>

<?php echo $__env->make('cms/cms_main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/laravel-shop/resources/views/cms/orders.blade.php ENDPATH**/ ?>