<?php $__env->startSection('home'); ?> 
<div class="row">
    <div class="col-md-12">
        <h1>My Shop categories</h1>
    </div>
</div>
<div class="row">
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-4 col-sm-6 pt-10">
        <a href="<?php echo e(url('shop/' .  $category['url'])); ?>" style="text-decoration: none; color:black">
        <h3>
            <?php echo e($category['title']); ?>

        </h3>
         
        <p><img src="<?php echo e(asset('images/' . $category['image'] )); ?>" width="200" height="225"></p>
        </a>
        <p><?php echo $category['article']; ?></p>

    </div>
        
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/laravel-shop/resources/views/content/categories.blade.php ENDPATH**/ ?>