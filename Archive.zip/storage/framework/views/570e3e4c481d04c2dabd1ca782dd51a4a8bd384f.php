<?php $__env->startSection('cms_content'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Add new product</h1>
</div>
<br><br>
  <div class="row">
    <div class="col-lg-8">
      <form action="<?php echo e(url('cms/products')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

        <div class="mb-3">
          <label for="categorie-id" class="form-label">Category:</label>
          <select name="categorie_id" id="categorie_id" class="form-control origin-tex">
            <option value="">Choose category</option>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option <?php if(old('categorie_id') == $category['id'] ): ?> selected="selected" <?php endif; ?> value="<?php echo e($category['id']); ?>"><?php echo e($category['title']); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>
          <div class="mb-3">
            <label for="title" class="form-label">Title:</label>
            <input name="title" type="text"  value="<?php echo e(old('title')); ?>" class="form-control origin-text" placeholder="title" id="title" aria-describedby="title">
          </div>
          <div class="mb-3">
            <label for="url" class="form-label">Url:</label>
            <input name="url" type="text"  value="<?php echo e(old('url')); ?>" class="form-control target-text" placeholder="url" id="url" aria-describedby="url">
          </div>
          <div class="mb-3">
            <label for="price" class="form-label">Price:</label>
            <input name="price" type="text"  value="<?php echo e(old('price')); ?>" class="form-control " placeholder="price" id="price" aria-describedby="price">
          </div>
          <div class="mb-3">
              <label for="article" class="form-label">Article:</label>
              <textarea id="article" name="article" class="form-control" rows="3"><?php echo e(old('article')); ?></textarea>
          </div>
          <div class="mb-3">
            <label for="image" class="form-label">Product image:</label>
            <input type="file" id="image" name="image" class="form-control" rows="3">
          </div>
          <a href="<?php echo e(url('cms/products')); ?>" class="btn btn-secondary">Cancel</a>
          <input class="btn btn-primary " type="submit" name="submit" value="Save">
      </form>
    </div>
  </div>

  <?php $__env->stopSection(); ?>

<?php echo $__env->make('cms/cms_main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/laravel-shop/resources/views/cms/add_product.blade.php ENDPATH**/ ?>