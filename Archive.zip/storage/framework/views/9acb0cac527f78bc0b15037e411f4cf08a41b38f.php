<?php $__env->startSection('cms_content'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h3 class="page-header">Are you sure you want to delete this item ?</h3>
</div>
<br><br>
  <div class="row">
    <div class="col-lg-8">
      <form action="<?php echo e(url('cms/products/' . $id )); ?>" method="post">  
        <?php echo e(csrf_field()); ?>

          <?php echo e(method_field('DELETE')); ?>


        <a href="<?php echo e(url('cms/products')); ?>" class="btn btn-secondary">Cancel</a>
          <input class="btn btn-danger " type="submit" name="submit" value="Delete">
    </form>
    </div>
  </div>

  <?php $__env->stopSection(); ?>

<?php echo $__env->make('cms/cms_main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/laravel-shop/resources/views/cms/delete_product.blade.php ENDPATH**/ ?>