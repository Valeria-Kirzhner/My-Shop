<?php $__env->startSection('home'); ?> 
<div class="row">
    <div class="col-md-12">
        <h1>Here you can sign in with your account </h1>
    </div>
</div>
<div class="row">
    <div class="col-md-6">
        <form action="" method="POST">
            <?php echo e(csrf_field()); ?>

            <div class="mb-3">
                <label for="email" class="form-label">Email address</label>
                <input name="email" value="<?php echo e(old('email')); ?>" type="text" class="form-control" id="email" aria-describedby="email" placeholder="alex@gmail.com">
              <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
            </div>
              <div class="mb-3">
                <label for="password" class="form-label">password</label>
                <input name="password" type="text" class="form-control" placeholder="password" id="password" aria-describedby="password">
                <span class="text-danger"> <?php echo e($errors->first('password')); ?></span>
            </div>
              <input class="btn btn-primary " type="submit" name="submit" value="Sign In" id="">
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/laravel-shop/resources/views/forms/signin.blade.php ENDPATH**/ ?>