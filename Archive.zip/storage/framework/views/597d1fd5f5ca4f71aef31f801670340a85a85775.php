<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($title); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.css')); ?>"> 
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <script> var BASE_URL= "<?php echo e(url('')); ?>";</script>
<body>
    <header>
      <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">
          <a class="navbar-brand" href="<?php echo e(url('')); ?>">MY SHOP </a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNavDropdown">
            <ul class="navbar-nav">
                <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item">
                  <a class="nav-link active" aria-current="page" href="<?php echo e(url($item['url'])); ?>"><?php echo e($item['link']); ?></a>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="<?php echo e(url('shop')); ?>">Shop</a>
              </li>
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="<?php echo e(url('shop/checkout')); ?>">
                  <img width="20" src="<?php echo e(asset('images/shopping-cart.png')); ?>" alt="">
                  <?php if( ! Cart::isEmpty()): ?>
                  <div class="total-cart"><?php echo e(Cart::getTotalQuantity()); ?></div>
                  <?php endif; ?>
                </a>
              </li>
          </ul>
          <ul class="navbar-nav navbar-right">
              <?php if( ! Session::has('user_id')): ?>
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="<?php echo e(url('user/signin')); ?>">Sign In</a>
              </li>
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="<?php echo e(url('user/signup')); ?>">Sign Up</a>
              </li> 
              <?php else: ?>
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="<?php echo e(url('user/profile')); ?>"><?php echo e(Session::get('user_name')); ?></a>
              </li>
              <?php if(Session::has('is_admin')): ?>
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="<?php echo e(url('cms/dashboard')); ?>">CMS dashboard</a>
              </li>
              <?php endif; ?>
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="<?php echo e(url('user/logout')); ?>">Logout</a>
              </li>
              <?php endif; ?>
          </ul>
          </div>
        </div>
      </nav>
    </header>
    <main style="min-height: 900px">
      <br>
      <div class="container">
        <?php if(Session::has('sm')): ?>
        <div class="row sm-box">
          <div class="col-md-12">
            <div class="alert alert-success"><?php echo e(Session::get('sm')); ?></div>
          </div>
        </div>
        <?php endif; ?>
            <?php if($errors->any()): ?>
              <div class="row">
                <div class="col-md-12">
                  <br>
                  <div class="alert alert-danger">
                    <ul>
                      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                        <li><?php echo e($error); ?></li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                  </div>
                </div>
              </div>
              <?php endif; ?>
        <?php echo $__env->yieldContent('home'); ?> 
      </div>
      <br>
    </main>
    <br>
    <hr>
    <footer>
         <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <p class="text-center">My-Shop &copy; <?php echo e(date('Y')); ?></p>
                </div>
            </div>
        </div>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <script rel="javascript" src="<?php echo e(asset('js/script.js')); ?>" type="text/javascript"></script>
</body>

</html><?php /**PATH /Applications/MAMP/htdocs/laravel-shop/resources/views/main.blade.php ENDPATH**/ ?>