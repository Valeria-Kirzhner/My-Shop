<?php $__env->startSection('home'); ?> 
<div class="row">
    <div class="col-md-12">
        <h1><?php echo e(str_replace('My SHOP | ', '', $title)); ?></h1>
    </div>
</div>
<?php if( !empty($products) ): ?>
<div class="row">
<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-md-6">
    <a href="<?php echo e(url('shop/' . $cat_url . '/' . $product['url'])); ?>" style="text-decoration: none; color:black">
    <h3><?php echo e($product['title']); ?></h3>
    <p><img width="300" height="400" src="<?php echo e(asset('images/' . $product['image'])); ?>" alt=""></p>
    </a>
    <p><?php echo $product['article']; ?></p>
    <p><b>Price: </b><?php echo e($product['price']); ?> $</p>
    <p>
        <?php if( ! Cart::get($product['id'])): ?>
        <input data-id="<?php echo e($product['id']); ?>" class="btn btn-success add-to-cart-btn" type="button" value="+ Add to cart">
        <?php else: ?>
        <input class="btn btn-success add-to-cart-btn" disabled="disabled" type="button" value="Item in cart">
        <?php endif; ?>
    </p>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/laravel-shop/resources/views/content/products.blade.php ENDPATH**/ ?>