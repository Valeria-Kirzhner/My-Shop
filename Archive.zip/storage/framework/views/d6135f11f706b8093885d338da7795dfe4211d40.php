<?php $__env->startSection('about'); ?> 
<div class="row">
    <div class="col-md-12">
        <h1>About MY SHOP </h1>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. <br>  
            Doloremque atque possimus laudantium tenetur obcaecati non ad blanditiis qui deserunt ipsa illo sunt, rem numquam vero, assumenda cum dolorum minus. Veniam.</p>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/laravel-shop/resources/views/about.blade.php ENDPATH**/ ?>