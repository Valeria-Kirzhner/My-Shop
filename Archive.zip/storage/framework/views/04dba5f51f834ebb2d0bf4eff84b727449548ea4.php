<?php $__env->startSection('home'); ?> 
<div class="row">
    <div class="col-md-12">
        <h1><?php echo e($product['title']); ?></h1>
        <p><img width="300" height="400" src="<?php echo e(asset('images/' . $product['image'])); ?>" alt=""></p>
        <p><?php echo $product['article']; ?></p>
        <p><b><?php echo e($product['price']); ?> $</b></p>
        <p>
            <?php if( ! Cart::get($product['id'])): ?>
            <input data-id="<?php echo e($product['id']); ?>" class="btn btn-success add-to-cart-btn" type="button" value="+ Add to cart">
            <?php else: ?>
            <input class="btn btn-success add-to-cart-btn" disabled="disabled" type="button" value="Added to cart">
            <?php endif; ?>
            <a class="btn btn-primary" href="<?php echo e(url('shop/checkout')); ?>">Checkout</a>
    </p>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/laravel-shop/resources/views/content/item.blade.php ENDPATH**/ ?>