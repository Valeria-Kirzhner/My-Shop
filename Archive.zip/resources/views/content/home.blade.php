@extends('main')
@section('home') 
<div class="row">
    <div class="col-md-12">
        <h1>Welcome to Home Page</h1>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. <br>  
            Doloremque atque possimus laudantium tenetur obcaecati non ad blanditiis qui deserunt ipsa illo sunt, rem numquam vero, assumenda cum dolorum minus. Veniam.</p>
    </div>
</div>
@endsection