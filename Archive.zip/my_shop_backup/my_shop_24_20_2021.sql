-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Oct 24, 2021 at 01:14 PM
-- Server version: 5.7.32
-- PHP Version: 7.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `my_shop`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `article` text NOT NULL,
  `url` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `title`, `article`, `url`, `image`, `updated_at`, `created_at`) VALUES
(1, 'Perfumes', 'Best prices for all the perfumes.', 'perfumes', 'pink-perfume-bottle.jpeg', '2021-10-12 23:26:42', '2021-10-12 23:26:42'),
(2, 'Cosmetics', 'Best prices for all the cosmetics.', 'cosmetics', 'face-makeup-compact-powder.jpeg', '2021-10-12 23:26:42', '2021-10-12 23:26:42'),
(3, 'Body Care', 'Creams and scrabs', 'body-care', 'm11015999999.jpeg', '2021-10-12 23:29:46', '2021-10-12 23:29:46');

-- --------------------------------------------------------

--
-- Table structure for table `contents`
--

CREATE TABLE `contents` (
  `id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `article` text NOT NULL,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `contents`
--

INSERT INTO `contents` (`id`, `menu_id`, `title`, `article`, `updated_at`, `created_at`) VALUES
(1, 1, 'About MY SHOP', ' It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', '2021-10-21 21:19:33', '2021-10-21 21:19:33'),
(2, 1, 'Our Vision', 'The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections and from \"de Finibus Bonorum et Malorum\" by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.', '2021-10-21 21:19:33', '2021-10-21 21:19:33'),
(3, 2, 'MY SHOP Services', 'The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from \"de Finibus Bonorum et Malorum\" by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.', '2021-10-21 21:29:30', '2021-10-21 21:29:30');

-- --------------------------------------------------------

--
-- Table structure for table `menus`
--

CREATE TABLE `menus` (
  `id` int(11) NOT NULL,
  `link` varchar(255) NOT NULL,
  `mtitle` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `menus`
--

INSERT INTO `menus` (`id`, `link`, `mtitle`, `url`, `updated_at`, `created_at`) VALUES
(1, 'About Us', 'About Page', 'about-us', '2021-10-21 15:51:06', '2021-10-21 15:51:06'),
(2, 'Services', 'Services Page', 'our-services', '2021-10-21 15:51:06', '2021-10-21 15:51:06'),
(3, 'Contact us', 'Contact', 'contact-us', '2021-10-21 15:51:47', '2021-10-21 15:51:47');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `data` text NOT NULL,
  `total` decimal(8,0) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `data`, `total`, `created_at`, `updated_at`) VALUES
(1, 7, 'a:2:{i:1;a:6:{s:2:\"id\";s:1:\"1\";s:4:\"name\";s:11:\"Coco Chanel\";s:5:\"price\";d:150;s:8:\"quantity\";i:1;s:10:\"attributes\";a:0:{}s:10:\"conditions\";a:0:{}}i:2;a:6:{s:2:\"id\";s:1:\"2\";s:4:\"name\";s:13:\"Chance Chanel\";s:5:\"price\";d:100;s:8:\"quantity\";i:1;s:10:\"attributes\";a:0:{}s:10:\"conditions\";a:0:{}}}', '250', '2021-10-21 12:19:55', '2021-10-21 12:19:55');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `categorie_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `article` text NOT NULL,
  `image` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `price` decimal(8,0) NOT NULL,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `categorie_id`, `title`, `article`, `image`, `url`, `price`, `updated_at`, `created_at`) VALUES
(1, 1, 'Coco Chanel', 'A floral fragrance in a round bottle. Unpredictable, in perpetual movement, CHANCE sweeps you into its whirlwind of happiness and fantasy. An olfactory encounter with chance.\r\n\r\n', 'coco-chanel.webp', 'coco-chanel-250', '150', '2021-10-13 20:31:54', '2021-10-13 20:31:54'),
(2, 1, 'Chance Chanel', 'A floral fragrance in a round bottle. Unpredictable, in perpetual movement, CHANCE sweeps you into its whirlwind of happiness and fantasy. An olfactory encounter with chance.\r\n', 'chance-chanel.jpeg', 'chance-chanel-250', '100', '2021-10-13 20:31:54', '2021-10-13 20:31:54'),
(3, 2, 'chanel Rouge Allure', 'CHANEL Rouge Allure Ink Matte Liquid Lip Colour 222 6ml', 'chanel-lipstick-589.jpeg', 'chanel-rogue-red', '55', '2021-10-13 20:38:43', '2021-10-13 20:38:43'),
(4, 2, 'Chanel VITALUMIÈRE AQUA', 'Ultra-Light Skin Perfecting Sunscreen Makeup Broad Spectrum SPF 15 Hybrid Fluid Foundation', 'chanel-powder-11.jpeg', 'chanel-powder-aqua-100', '139', '2021-10-13 20:38:43', '2021-10-13 20:38:43'),
(5, 3, 'Acqua Body Cream', 'The body cream of the Colonia collection created by Acqua di Parma has a moisturising, smoothing and protective effect while leaving behind the signature essence of Colonia.', 'aqua-body-cream.jpg', 'aqua-body-cream', '60', '2021-10-13 20:43:51', '2021-10-13 20:43:51'),
(6, 3, 'Caudalie Strowberry', 'A firming body cream with 97% natural-origin ingredients, Whipped & creamy texture dissolves easily without leaving a greasy film.', 'caudalie-body-cream.jpeg', 'caudalie-body-cream', '80', '2021-10-13 20:43:51', '2021-10-13 20:43:51');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `updated_at`, `created_at`) VALUES
(1, '-', '-', '-', '2021-10-20 09:34:41', '2021-10-20 09:34:41'),
(2, '--', '--', '--', '2021-10-20 09:34:41', '2021-10-20 09:34:41'),
(3, 'admin', 'admin@gmail.com', '$2y$10$EL2dJXf0tLkyY4TzGV/tlO2ux.xvaAavQz0ONTCv3.BdUhemLnNZq', '2021-10-20 09:36:31', '2021-10-20 09:36:31'),
(4, 'Avi Cohen', 'avi@gmail.com', '$2y$10$EL2dJXf0tLkyY4TzGV/tlO2ux.xvaAavQz0ONTCv3.BdUhemLnNZq', '2021-10-20 09:37:53', '2021-10-20 09:37:53'),
(5, 'Shimi Levi', 'shimi@gmail.com', '$2y$10$EL2dJXf0tLkyY4TzGV/tlO2ux.xvaAavQz0ONTCv3.BdUhemLnNZq', '2021-10-20 09:37:53', '2021-10-20 09:37:53'),
(6, 'popaye', 'popaye@gmail.com', '$2y$10$uotModrNwWRSRaWYqmyuxeP8.eaDHu9C4X9x1fwZBC9r.gZBdshMu', '2021-10-20 17:13:30', '2021-10-20 17:13:30'),
(7, 'dodo', 'dodo@gmail.com', '$2y$10$eFC1qWiTL74i06mc56u3ger7i89VvHQOLJdaeJZAAw/jGo78XZqhG', '2021-10-20 17:15:07', '2021-10-20 17:15:07');

-- --------------------------------------------------------

--
-- Table structure for table `user_roles`
--

CREATE TABLE `user_roles` (
  `uid` int(11) NOT NULL,
  `role` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_roles`
--

INSERT INTO `user_roles` (`uid`, `role`) VALUES
(3, 6),
(4, 7),
(5, 7),
(7, 7);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `url` (`url`);

--
-- Indexes for table `contents`
--
ALTER TABLE `contents`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menus`
--
ALTER TABLE `menus`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `url` (`url`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `url` (`url`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `contents`
--
ALTER TABLE `contents`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `menus`
--
ALTER TABLE `menus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
